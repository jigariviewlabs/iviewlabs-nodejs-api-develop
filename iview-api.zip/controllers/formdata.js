const pvisitor = require('../models/dbQueries')
const db = require('../utils/db');

async function visitordata(req, res, next) {

    const {name,email,contactnumber,companyname,websitelink,companysize,roles,lookingfor,budget,aboutus,comments}=req.body;
    const id = req.params.id;
    if (name && email && contactnumber && companyname && websitelink  &&companysize && roles && lookingfor && budget && aboutus && comments){
            const result = await db.query(`UPDATE visitordata SET submit = 'done' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
        else{
            res.send({ "status": "error", "message": "provide all feilds"})
        }
    // const jdata = await pvisitor.visitorsData(name, email, contactnumber, companyname, websitelink, companysize, roles, lookingfor, budget, aboutus, comments, submit)
    
    

}
async function next(req, res) {
    const { name, email, contactnumber, companyname, websitelink, companysize, roles, lookingfor, budget, aboutus, comments, submit } = req.body;
    const id = req.params.id;
    console.log("id",id);
    console.log("name", name);
    if(name !== undefined){
        if(id == 0){
            const result = await db.query(`INSERT INTO visitordata (name) VALUES ('${name}')`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + rows.insertId,rows)
                    res.send({ "status": "success","id": rows.insertId ,"name":name})
                })
                .catch((err) => {
                    console.log("err",err)
                })
                
        }
        else{
            if (id !== null) {
                const result = await db.query(`UPDATE visitordata SET name = '${name}' WHERE id = '${id}'`)
                    .then((rows) => {
                        console.log("1 record inserted, ID: " + id, rows)
                        res.send({ "status": "success", "id": id,"name":name })
                    })
                    .catch((err) => {
                        console.log("err", err)
                    })
            }
        }
        
    }
    else if (email !== undefined)
    {
        console.log("in email")
        if(id !== null){
            const result = await db.query(`UPDATE visitordata SET email = '${email}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"email":email })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (contactnumber !== undefined) {
        console.log("in contactnumber")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET contactnumber = '${contactnumber}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"contactnumber":contactnumber })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (companyname !== undefined) {
        console.log("in companyname")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET companyname = '${companyname}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"companyname":companyname})
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (websitelink !== undefined) {
        console.log("in websitelink")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET websitelink = '${websitelink}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id, "websitelink": websitelink })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (companysize !== undefined) {
        console.log("in companysize")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET companysize = '${companysize}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"companysize":companysize })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (roles !== undefined) {
        console.log("in roles")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET roles = '${roles}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"roles":roles})
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (lookingfor !== undefined) {
        console.log("in lookingfor")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET lookingfor = '${lookingfor}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"lookingfor":lookingfor })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (budget !== undefined) {
        console.log("in budget")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET budget = '${budget}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id, "budget": budget })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (aboutus !== undefined) {
        console.log("in aboutus")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET aboutus = '${aboutus}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"aboutus":aboutus })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (comments !== undefined) {
        console.log("in comments")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET comments = '${comments}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"comments":comments})
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else if (submit !== undefined) {
        console.log("in submit")
        if (id !== null) {
            const result = await db.query(`UPDATE visitordata SET submit = '${submit}' WHERE id = '${id}'`)
                .then((rows) => {
                    console.log("1 record inserted, ID: " + id, rows)
                    res.send({ "status": "success", "id": id,"submit":submit })
                })
                .catch((err) => {
                    console.log("err", err)
                })
        }
    }
    else{
        res.send({ "status": "error", "message":"extra field"})
    }

}
module.exports = { visitordata,next };