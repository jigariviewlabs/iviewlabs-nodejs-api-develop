# iviewlabs-nodejs-api
# nodejs-apis

rewrite the APIs in Nodejs from the PHP Codeigniter framework

---
## Requirements

For using this Node application you will need Node js installation on your system.
You will require postman to send form-data.

To test this application on your system:

1.) Open working directory in editor
2.) Initailize the working directory with npm ie(npm init)
3.) Intall necessary packages
4.) Run the application using npm start command
5.) You need to open postman and send neccessary form-data fields.
6.) Send a POST request from POSTMAN
7.) Now you can check for mails at particular id + your console for the output
8.) API's created:
    ->  /api/contact/modalcontactus                 (Mail is sent to visitor as well as company.)
    ->  /api/contact/openingapplication
    ->  /api/contact/sendopeningapplicationmail     (Mail is sent to visitor as well as company.)
    ->  /api/hiredeveloper/hireourresource          (Mail is sent to visitor as well as company.)
    ->  /api/contactus/inquiry                      (Mail is sent to visitor as well as company.)
    ->  /api/carrier/currentopening
    ->  /api/upload
